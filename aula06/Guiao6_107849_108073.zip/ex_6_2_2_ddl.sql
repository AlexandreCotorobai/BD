SET NOCOUNT ON
GO

set nocount    on

USE master

GO

if exists (select * from sysdatabases where name='geststocks')
begin
  raiserror('Dropping existing getstocks database ....',0,1)
  DROP database geststocks
end
GO

CHECKPOINT
go

raiserror('Creating getstocks database....',0,1)
go
/*
   Use default size with autogrow
*/

CREATE DATABASE geststocks
GO

USE geststocks  

GO




CREATE TABLE tipo_fornecedor
(
    codigo INT NOT NULL,
    designacao VARCHAR(50) NOT NULL,

    PRIMARY KEY (codigo),
)

GO

CREATE TABLE fornecedor
(
    nif INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    fax INT,
    endereco VARCHAR(50),
    condpag INT NOT NULL,
    tipo INT NOT NULL,

    PRIMARY KEY (nif),
    FOREIGN KEY (tipo) REFERENCES tipo_fornecedor(codigo),
)

GO

CREATE TABLE produto 
(
    codigo INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    preco FLOAT NOT NULL,
    iva INT NOT NULL,
    unidades INT NOT NULL,

    PRIMARY KEY (codigo),
)

GO

CREATE TABLE encomenda
(
    numero INT NOT NULL,
    data DATE NOT NULL,
    fornecedor INT NOT NULL,

    PRIMARY KEY (numero),
    FOREIGN KEY (fornecedor) REFERENCES fornecedor(nif)
)

GO

CREATE TABLE item
(
    numEnc INT NOT NULL,
    codProd INT NOT NULL,
    unidades INT NOT NULL,

    PRIMARY KEY (numEnc, codProd),
    FOREIGN KEY (numEnc) REFERENCES encomenda(numero),
    FOREIGN KEY (codProd) REFERENCES produto(codigo),
)

GO