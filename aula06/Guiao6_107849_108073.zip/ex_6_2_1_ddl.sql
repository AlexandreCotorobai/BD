SET NOCOUNT ON
GO

set nocount    on

USE master

GO

if exists (select * from sysdatabases where name='empresa')
begin
  raiserror('Dropping existing empresa database ....',0,1)
  DROP database empresa
end
GO

CHECKPOINT
go

raiserror('Creating empresa database....',0,1)
go
/*
   Use default size with autogrow
*/

CREATE DATABASE empresa
GO

USE empresa

GO




CREATE TABLE employee
(
    Fname VARCHAR(50) NOT NULL,
    Minit VARCHAR(50) NOT NULL,
    Lname VARCHAR(50) NOT NULL,
    Ssn INT NOT NULL,
    Bdate DATE NOT NULL,
    Address VARCHAR(50),
    Sex VARCHAR(50) NOT NULL,
    Salary FLOAT NOT NULL,
    Super_ssn INT,
    Dno INT,

    PRIMARY KEY (Ssn),
    FOREIGN KEY (Super_ssn) REFERENCES employee(Ssn),
)

GO

CREATE TABLE department
(
    Dname VARCHAR(50) NOT NULL,
    Dnumber INT NOT NULL,
    Mgr_ssn INT,
    Mgr_Start_Date DATE,

    PRIMARY KEY (Dnumber),
    FOREIGN KEY (Mgr_ssn) REFERENCES employee(Ssn),
)

GO

ALTER TABLE employee ADD FOREIGN KEY (Dno) REFERENCES department(Dnumber)

GO

CREATE TABLE dependent 
(
    Essn INT NOT NULL,
    Dependent_name VARCHAR(50) NOT NULL,
    Sex VARCHAR(50) NOT NULL,
    Bdate DATE NOT NULL,
    Relationship VARCHAR(50) NOT NULL,

    PRIMARY KEY (Essn, Dependent_name),
    FOREIGN KEY (Essn) REFERENCES employee(Ssn),
)

GO

CREATE TABLE dept_locations
(
    Dnumber INT NOT NULL,
    Dlocation VARCHAR(50) NOT NULL,

    PRIMARY KEY (Dnumber, Dlocation),
    FOREIGN KEY (Dnumber) REFERENCES department(Dnumber),
)

GO

CREATE TABLE project
(
    Pname VARCHAR(50) NOT NULL,
    Pnumber INT NOT NULL,
    Plocation VARCHAR(50) NOT NULL,
    Dnum INT NOT NULL,
    
    PRIMARY KEY (Pnumber),
    FOREIGN KEY (Dnum) REFERENCES department(Dnumber),
)

GO

CREATE TABLE works_on
(
    Essn INT NOT NULL,
    Pno INT NOT NULL,
    Hours FLOAT NOT NULL,

    PRIMARY KEY (Essn, Pno),
    FOREIGN KEY (Essn) REFERENCES employee(Ssn),
    FOREIGN KEY (Pno) REFERENCES project(Pnumber),
)

GO