# BD: Guião 9


## ​9.1
 
### *a)*

```
CREATE PROCEDURE RemoveEmployee @Ssn INT
AS
    BEGIN
        IF NOT EXISTS (SELECT * FROM Employee WHERE Ssn = @Ssn)
            BEGIN
                RAISERROR('Employee does not exist', 16, 1)
                RETURN
            END;
        IF EXISTS (SELECT * FROM department WHERE Mgr_ssn = @Ssn)
            BEGIN
                UPDATE department SET Mgr_ssn = NULL WHERE Mgr_ssn = @Ssn
            END;
        iF EXISTS (SELECT * FROM employee WHERE Super_ssn = @Ssn)
            BEGIN
                UPDATE employee SET Super_ssn = NULL WHERE Super_ssn = @Ssn
            END;
        
        DELETE FROM works_on WHERE Essn = @Ssn
        DELETE From dependent WHERE Essn = @Ssn
        DELETE FROM employee WHERE Ssn = @Ssn
    END;
```

### *b)* 

```
CREATE PROCEDURE GetMangers (@ossn as INT OUTPUT, @oyears as INT OUTPUT)
AS
    BEGIN
    
        SELECT @ossn = Mgr_ssn, @oyears = DATEDIFF(YEAR, Mgr_start_date, GETDATE())
        FROM department WHERE Mgr_start_date IS NOT NULL ORDER BY Mgr_start_date DESC


        SELECT * FROM employee
        WHERE SSN IN (SELECT Mgr_ssn FROM department)
    END;
```

### *c)* 

```
CREATE TRIGGER ManagerSetTrigger 
    ON Department
    AFTER INSERT, UPDATE
    AS
        BEGIN
            DECLARE @ManagerSsn INT
            DECLARE @DepartmentNumber INT

            SELECT @ManagerSsn = Mgr_ssn, @DepartmentNumber = Dnumber
            FROM inserted

            -- check if manager is already a manager
            IF EXISTS (SELECT * FROM department WHERE Mgr_ssn = @ManagerSsn AND Dnumber <> @DepartmentNumber)
                BEGIN
                    RAISERROR('Manager is already a manager of another department', 16, 1)
                    ROLLBACK TRANSACTION
                END;
            
        END;
```

### *d)* 

```
CREATE TRIGGER EmployeeSalaryCheckTrigger
ON Employee
AFTER INSERT, UPDATE
AS
    BEGIN
        DECLARE @Salary DECIMAL(10,2)
        DECLARE @Ssn INT
        DECLARE @ManagerSsn INT
        DECLARE @ManagerSalary DECIMAL(10,2)

        SELECT @Salary = Salary, @Ssn = Ssn, @ManagerSsn = Mgr_ssn
        FROM inserted

        SELECT @ManagerSalary = Salary
        FROM employee
        WHERE Ssn = @ManagerSsn

        IF @Salary > @ManagerSalary
            BEGIN
                -- update salary to manager salary - 1
                UPDATE employee
                SET Salary = @ManagerSalary - 1
                WHERE Ssn = @Ssn
            END;
    END;
```

### *e)* 

```
CREATE FUNCTION EmployeeInfo
(
    @Ssn INT
)
RETURNS TABLE
AS
RETURN
    SELECT PNAME, PLOCATION
    FROM project
    WHERE Pnumber IN (SELECT Pno FROM works_on WHERE Essn = @Ssn);
```

### *f)* 

```
CREATE FUNCTION GetEmployeeGRavgSalary
(
    @Dno INT
)
RETURNS TABLE
AS
RETURN
    SELECT *
    FROM Employee
    WHERE salary > (SELECT AVG(Salary) FROM Employee WHERE Dno = @Dno);
```

### *g)* 

```
CREATE FUNCTION employeeDeptHighAverage( @Dno INT ) RETURNS @Output TABLE (Pname VARCHAR(50), pnumber INT, plocation VARCHAR(50), dnum INT, budget DECIMAL(10,2), totalbudget DECIMAL(10,2))
AS
    BEGIN
    DECLARE @Pname VARCHAR(50),
            @Pnumber INT,
            @Plocation VARCHAR(50),
            @Dnum INT,
            @Budget DECIMAL(10,2),
            @TotalBudget DECIMAL(10,2);


    DECLARE project_cursor CURSOR FOR
    SELECT Pname, Pnumber, Plocation, Dnum FROM project WHERE Dnum = @Dno;
    SELECT @TotalBudget = 0;
    OPEN project_cursor;
    FETCH NEXT FROM project_cursor INTO @Pname, @Pnumber, @Plocation, @Dnum;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- calculate budget, its the sum of salary of each employee working on the project * hours
        SELECT @Budget = SUM(Salary/1.6) FROM employee, works_on WHERE employee.Ssn = works_on.Essn AND works_on.Pno = @Pnumber;
        -- calculate total budget, its the sum of budget of each project in the department
        SELECT @TotalBudget = @TotalBudget + @Budget

        INSERT INTO @Output (Pname, Pnumber, Plocation, Dnum, Budget, TotalBudget) VALUES (@Pname, @Pnumber, @Plocation, @Dnum, @Budget, @TotalBudget);

        FETCH NEXT FROM project_cursor INTO @Pname, @Pnumber, @Plocation, @Dnum;
    END;

    CLOSE project_cursor;
    DEALLOCATE project_cursor;
    RETURN;
    END;
```

### *h)* 

```
CREATE TRIGGER DeleteDepartmentTrigger
ON Department
AFTER DELETE
AS
    BEGIN 
        -- CHECK IF TABLE EXISTS
        IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'department_deleted '))
            BEGIN
                CREATE TABLE department_deleted (
                    Dnumber INT,
                    Dname VARCHAR(50),
                    Mgr_ssn INT,
                    Mgr_start_date DATE
                );
            END;               

        INSERT INTO department_deleted (Dnumber, Dname, Mgr_ssn, Mgr_start_date) 
        (SELECT Dnumber, Dname, Mgr_ssn, Mgr_start_date FROM deleted);
    END;

CREATE TRIGGER DeleteDepartmentTrigger2
ON Department
INSTEAD OF DELETE
AS
    BEGIN

        IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'department_deleted '))
            BEGIN
                CREATE TABLE department_deleted (
                    Dnumber INT,
                    Dname VARCHAR(50),
                    Mgr_ssn INT,
                    Mgr_start_date DATE
                );
            END;

        INSERT INTO department_deleted (Dnumber, Dname, Mgr_ssn, Mgr_start_date)
        (SELECT Dnumber, Dname, Mgr_ssn, Mgr_start_date FROM deleted);

        UPDATE employee SET Dno = NULL WHERE Dno IN (SELECT Dnumber FROM deleted);

    
        DELETE FROM WORKS_ON WHERE Pno IN (SELECT Pnumber FROM project WHERE Dnum IN (SELECT Dnumber FROM deleted));
        DELETE FROM project WHERE Dnum IN (SELECT Dnumber FROM deleted);
        DELETE FROM dept_locations WHERE Dnumber IN (SELECT Dnumber FROM deleted);
        DELETE FROM department WHERE Dnumber IN (SELECT Dnumber FROM deleted);
    END;
```

### *i)* 

```
Mais valias Stored procedure:
- Extensibility
- Performance
- Usability
- Data Integrity
- Security

Mais valias UDF:
Mesmas dos Stored Procedures
- Podem ser utilizadas para incorporar lógica complexa dentro de uma consulta
- Oferecem os mesmo benefícios das vistas pois podem ser utilizados como fonte de dados nas consultas e nas cláusulas WHERE/HAVING
- Criação de novas funções contendo expressões complexas

Caracteristicas distintivas:

| SP                                         | UDF                                     |
|--------------------------------------------|-----------------------------------------|
| return - zero, single or multiple values   | return - single value (scalar or table) |
| input/output param                         | input param                             |
| cannot use SELECT/ WHERE/ HAVING statement | can use SELECT/ WHERE/ HAVING statement |
| call SP – OK                               | call SP - NOK                           |
| exception handling - OK                    | exception handling - NOK                |
| transactions – OK                          | transaction - NOK                       |

SP - é usado caso seja necessário executar uma série de operações, operações essas que podem envolver varias tabelas, assim com uma stored procedure o processo é automatizado e otimizado

UDF - é usado caso seja preciso fazer varios calculos com base em consultas SQL, a UDF permite abstrair as operações dentro dela e tornar o seu uso mais fácil

```
