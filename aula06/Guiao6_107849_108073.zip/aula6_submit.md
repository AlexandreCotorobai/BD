# BD: Guião 6

## Problema 6.1

### *a)* Todos os tuplos da tabela autores (authors);

```
SELECT * FROM authors;
```

### *b)* O primeiro nome, o último nome e o telefone dos autores;

```
SELECT au_fname, au_lname, phone FROM authors;
```

### *c)* Consulta definida em b) mas ordenada pelo primeiro nome (ascendente) e depois o último nome (ascendente); 

```
SELECT au_fname, au_lname, phone
FROM authors
ORDER BY au_fname, au_lname ASC;
```

### *d)* Consulta definida em c) mas renomeando os atributos para (first_name, last_name, telephone); 

```
SELECT au_fname AS first_name, au_lname AS last_name, phone AS telephone
FROM authors
ORDER BY au_fname, au_lname ASC;
```

### *e)* Consulta definida em d) mas só os autores da Califórnia (CA) cujo último nome é diferente de ‘Ringer’; 

```
SELECT au_fname AS first_name, au_lname AS last_name, phone AS telephone, state
FROM authors
WHERE state = 'CA'
ORDER BY au_fname, au_lname ASC;
```

### *f)* Todas as editoras (publishers) que tenham ‘Bo’ em qualquer parte do nome; 

```
SELECT * FROM publishers
WHERE pub_name LIKE '%Bo%';
```

### *g)* Nome das editoras que têm pelo menos uma publicação do tipo ‘Business’; 

```
SELECT DISTINCT pub_name
FROM (SELECT p.pub_id, pub_name
      FROM publishers p
      JOIN titles t ON p.pub_id = t.pub_id
      WHERE t.type = 'business')
AS suby;
```

### *h)* Número total de vendas de cada editora; 

```
SELECT pub_id, sum(s.qty) AS sales 
FROM sales AS s INNER JOIN titles AS t ON s.title_id = t.title_id
GROUP BY pub_id;
```

### *i)* Número total de vendas de cada editora agrupado por título; 

```
SELECT pub_id, s.title_id, sum(s.qty) AS sales
FROM sales AS s INNER JOIN titles AS t ON s.title_id = t.title_id
GROUP BY pub_id, s.title_id;
```

### *j)* Nome dos títulos vendidos pela loja ‘Bookbeat’; 

```
SELECT title
FROM stores AS sto
INNER JOIN sales AS sal
ON sto.stor_id = sal.stor_id
INNER JOIN titles AS t
ON t.title_id = sal.title_id
WHERE sto.stor_name = 'Bookbeat'
```

### *k)* Nome de autores que tenham publicações de tipos diferentes; 

```
SELECT au_fname AS 'First name', au_lname AS 'Last name'
FROM authors, titles, titleauthor
WHERE authors.au_id = titleauthor.au_id and titles.title_id = titleauthor.title_id
GROUP BY au_lname, au_fname HAVING count(DISTINCT titles.type) > 1;
```

### *l)* Para os títulos, obter o preço médio e o número total de vendas agrupado por tipo (type) e editora (pub_id);

```
SELECT t.type, t.pub_id, avg(t.price) AS avergeprice, sum(s.qty) AS quantity FROM titles AS t
INNER JOIN sales AS s
ON s.title_id = t.title_id
GROUP BY t.type, t.pub_id;
```

### *m)* Obter o(s) tipo(s) de título(s) para o(s) qual(is) o máximo de dinheiro “à cabeça” (advance) é uma vez e meia superior à média do grupo (tipo);

```
SELECT title, price, avgprice
FROM ( SELECT type, avg(price) AS avgprice FROM titles GROUP BY type) AS avgpricetable
INNER JOIN titles ON avgpricetable.type = titles.type
WHERE titles.price >= avgpricetable.avgprice
```

### *n)* Obter, para cada título, nome dos autores e valor arrecadado por estes com a sua venda;

```
SELECT a.au_lname, a.au_fname, t.title, (t.price*t.ytd_sales) AS sale_value
FROM titles AS t
INNER JOIN titleauthor AS ta ON t.title_id = ta.title_id
INNER JOIN authors AS a ON a.au_id = ta.au_id
WHERE (t.price*t.ytd_sales) > -1
```

### *o)* Obter uma lista que incluía o número de vendas de um título (ytd_sales), o seu nome, a faturação total, o valor da faturação relativa aos autores e o valor da faturação relativa à editora;

```
SELECT title, ytd_sales, (ytd_sales * price) AS faturacao, (ytd_sales * price * royalty / 100 ) AS auths_revenue, (ytd_sales * price *  (100 - royalty) / 100	) AS publisher_revenue
FROM titles 
ORDER BY title ASC;
```

### *p)* Obter uma lista que incluía o número de vendas de um título (ytd_sales), o seu nome, o nome de cada autor, o valor da faturação de cada autor e o valor da faturação relativa à editora;

```
SELECT title, ytd_sales, CONCAT(au_fname, ' ', au_lname) AS author, (ytd_sales * price * royalty * royaltyper / 1000 ) AS auth_revenue, (ytd_sales * price *  (100 - royalty) / 100	) AS publisher_revenue
FROM titles
INNER JOIN titleauthor ON titles.title_id = titleauthor.title_id 
INNER JOIN authors ON titleauthor.au_id = authors.au_id
ORDER BY title ASC;
```

### *q)* Lista de lojas que venderam pelo menos um exemplar de todos os livros;

```
SELECT stores.stor_name
FROM stores
LEFT JOIN sales ON stores.stor_id = sales.stor_id
LEFT JOIN titles ON sales.title_id = titles.title_id
GROUP BY stores.stor_name
HAVING COUNT(DISTINCT titles.title_id) = (SELECT COUNT(*) FROM titles);
```

### *r)* Lista de lojas que venderam mais livros do que a média de todas as lojas;

```
SELECT stores.stor_name, SUM(sales.qty) AS total_sales
FROM stores
JOIN sales ON stores.stor_id = sales.stor_id
GROUP BY stores.stor_name
HAVING SUM(sales.qty) > (SELECT AVG(total_sales) FROM 
(SELECT SUM(s.qty) AS total_sales FROM sales s GROUP BY s.stor_id) AS store_sales);
```

### *s)* Nome dos títulos que nunca foram vendidos na loja “Bookbeat”;

```
SELECT title
FROM titles
WHERE titles.title_id NOT IN 
(SELECT sales.title_id FROM stores
INNER JOIN sales on stores.stor_id = sales.stor_id
WHERE stores.stor_name = 'Bookbeat')
```

### *t)* Para cada editora, a lista de todas as lojas que nunca venderam títulos dessa editora; 

```
SELECT publishers.pub_name, stores.stor_name
FROM publishers
JOIN titles ON publishers.pub_id = titles.pub_id
JOIN sales ON titles.title_id = sales.title_id
JOIN stores ON sales.stor_id = stores.stor_id
GROUP BY publishers.pub_name, stores.stor_name
```

## Problema 6.2

### ​5.1

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_1_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_1_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
SELECT project.Pname, project.Pnumber, employee.Ssn, employee.Fname, employee.Lname
FROM project
INNER JOIN works_on ON project.Pnumber = works_on.Pno
INNER JOIN employee ON works_on.Essn = employee.Ssn
```

##### *b)* 

```
SELECT *
FROM employee S1, (SELECT Ssn AS SupSsn, Fname AS SupFname,
Minit AS SupMinit, Lname AS SupLname FROM employee 
WHERE Fname = 'Carlos' AND Minit = 'D' AND Lname = 'Gomes') S2
WHERE S1.Super_ssn = S2.SupSsn
```

##### *c)* 

```
SELECT project.Pname, SUM(works_on.Hours) AS FullHours
FROM project
INNER JOIN works_on ON project.Pnumber = works_on.Pno
GROUP BY project.Pname
```

##### *d)* 

```
SELECT employee.Fname, employee.Minit, employee.Lname, employee.Dno, works_on.Hours
FROM employee
INNER JOIN works_on ON employee.Ssn = works_on.Essn
INNER JOIN project ON works_on.Pno = project.Pnumber
WHERE employee.Dno = 3 AND works_on.Hours > 20 AND project.Pname = 'Aveiro Digital'
```

##### *e)* 

```
SELECT employee.Fname, employee.Lname
FROM employee
LEFT JOIN works_on ON employee.Ssn = works_on.Essn
WHERE works_on.Essn IS NULL
```

##### *f)* 

```
SELECT department.Dname, AVG(employee.Salary) AS AvgSal
FROM department
JOIN employee ON department.Dnumber = employee.Dno
WHERE employee.Sex = 'F'
GROUP BY employee.Dno, department.Dname
```

##### *g)* 

```
SELECT employee.Fname, employee.Lname, employee.Ssn, COUNT(dependent.Essn) AS DepNo
FROM employee
JOIN dependent ON employee.Ssn = dependent.Essn
GROUP BY employee.Fname, employee.Lname, employee.Ssn
HAVING COUNT(dependent.Essn) > 2
```

##### *h)* 

```
SELECT employee.Fname, employee.Minit, employee.Lname
FROM employee
JOIN department ON employee.Ssn = department.Mgr_ssn
LEFT JOIN dependent ON employee.Ssn = dependent.Essn
WHERE dependent.Dependent_name IS NULL
```

##### *i)* 

```
SELECT DISTINCT newtable2.Fname, newtable2.Minit, newtable2.Lname, newtable2.Address
FROM dept_locations
JOIN (
     SELECT *
     FROM project
     JOIN (
         SELECT *
         FROM employee
         JOIN works_on ON employee.Ssn = works_on.Essn
        
     ) AS newtable ON project.Pnumber = newtable.Pno
     WHERE project.Plocation = 'Aveiro'
    )
  AS newtable2 ON dept_locations.Dnumber = newtable2.Dno
WHERE dept_locations.Dlocation <> 'Aveiro'
```

### 5.2

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_2_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_2_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
SELECT fornecedor.nif, fornecedor.nome
FROM fornecedor
LEFT JOIN encomenda ON fornecedor.nif = encomenda.fornecedor
WHERE encomenda.numero IS NULL
```

##### *b)* 

```
SELECT item.codProd, AVG(item.unidades) AS AvgUnidades
FROM item
GROUP BY item.codProd
```


##### *c)* 

```
SELECT AVG(Cast(X.totalProdutos AS FLOAT)) AS AvgProd
FROM (SELECT item.numEnc, COUNT(item.codProd) AS totalProdutos
    FROM item
    GROUP BY item.numEnc) AS X
```


##### *d)* 

```
SELECT produto.nome, fornecedor.nome, SUM(item.unidades) AS TotalUnidades
FROM produto
INNER JOIN item ON produto.codigo = item.codProd
INNER JOIN encomenda ON item.numEnc = encomenda.numero
INNER JOIN fornecedor ON encomenda.fornecedor = fornecedor.nif
GROUP BY produto.nome, fornecedor.nome
```

### 5.3

#### a) SQL DDL Script
 
[a) SQL DDL File](ex_6_2_3_ddl.sql "SQLFileQuestion")

#### b) Data Insertion Script

[b) SQL Data Insertion File](ex_6_2_3_data.sql "SQLFileQuestion")

#### c) Queries

##### *a)*

```
SELECT *
FROM paciente
LEFT JOIN prescricao
ON paciente.numUtente = prescricao.numUtente
WHERE prescricao.numPresc IS NULL
```

##### *b)* 

```
SELECT especialidade, COUNT(especialidade) as numReceitas
from medico
INNER JOIN prescricao 
ON numSNS = numMedico
GROUP BY especialidade
```


##### *c)* 

```
SELECT farmacia, COUNT(farmacia) as NoPrescricao
FROM prescricao
WHERE farmacia IS NOT NULL
GROUP BY farmacia
```


##### *d)* 

```
select farmaco.numRegFarm, nome, formula
FROM farmaco
LEFT JOIN presc_farmaco 
ON nome = nomeFarmaco
WHERE farmaco.numRegFarm = 906 AND numPresc IS NULL
```

##### *e)* 

```
SELECT farmacia, numRegFarm, COUNT(prescricao.numPresc) AS NoSales
FROM prescricao
INNER JOIN presc_farmaco 
ON prescricao.numPresc = presc_farmaco.numPresc
WHERE farmacia IS NOT NULL
GROUP BY farmacia, numRegFarm
```

##### *f)* 

```
SELECT *
FROM paciente
INNER JOIN (
	SELECT numUtente, COUNT(numUtente) AS NoUniqueMedics
	FROM (
		SELECT numUtente, numMedico, COUNT(numMedico) AS NoMedics
		FROM prescricao
		GROUP BY numUtente, numMedico
		) AS tableOfMedics
	GROUP BY numUtente
	) AS UniqueMedicsTable
ON paciente.numUtente = UniqueMedicsTable.numUtente
WHERE NoUniqueMedics > 1
```
